import crypto from "node:crypto";

// Проверяем, что запрос пришёл из Telegram Mini App (подпись initData).
function fromTelegram(initData, token) {
  if (!initData || !token) return false;
  const p = new URLSearchParams(initData);
  const hash = p.get("hash");
  p.delete("hash");
  const data = [...p.entries()].map(([k, v]) => `${k}=${v}`).sort().join("\n");
  const secret = crypto.createHmac("sha256", "WebAppData").update(token).digest();
  const calc = crypto.createHmac("sha256", secret).update(data).digest("hex");
  const age = Date.now() / 1000 - Number(p.get("auth_date") || 0);
  return calc === hash && age < 86400;
}

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();
  if (!fromTelegram(req.headers["x-tg-init"], process.env.BOT_TOKEN)) {
    return res.status(401).json({ error: "unauthorized" });
  }
  const prompt = String((req.body || {}).prompt || "").slice(0, 2000);
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 1200,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!r.ok) return res.status(502).json({ error: "upstream" });
  const j = await r.json();
  const text = (j.content || []).map((b) => b.text || "").join("").replace(/```json|```/g, "").trim();
  try {
    return res.status(200).json(JSON.parse(text));
  } catch {
    return res.status(502).json({ error: "bad json" });
  }
}
